import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';

class ScoreRing extends StatefulWidget {
  final int score;
  final int maxScore;
  final double size;
  final double strokeWidth;
  final String? label;
  final bool showPercent;
  final Color activeColor;

  const ScoreRing({
    super.key,
    required this.score,
    this.maxScore = 100,
    this.size = 110,
    this.strokeWidth = 7.0,
    this.label = 'Confidence Score',
    this.showPercent = false,
    this.activeColor = AppColors.accent,
  });

  @override
  State<ScoreRing> createState() => _ScoreRingState();
}

class _ScoreRingState extends State<ScoreRing> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _progressAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    );

    final double targetFraction =
        (widget.score / widget.maxScore).clamp(0.0, 1.0);

    _progressAnimation = Tween<double>(begin: 0.0, end: targetFraction).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeOutCubic),
    );

    _controller.forward();
  }

  @override
  void didUpdateWidget(covariant ScoreRing oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.score != widget.score) {
      _controller.forward(from: 0.0);
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _progressAnimation,
      builder: (context, child) {
        final currentScore =
            (_progressAnimation.value * widget.maxScore).round();

        return CustomPaint(
          size: Size(widget.size, widget.size),
          painter: _ScoreRingPainter(
            progress: _progressAnimation.value,
            strokeWidth: widget.strokeWidth,
            activeColor: widget.activeColor,
            trackColor: AppColors.neutralPill,
          ),
          child: SizedBox(
            width: widget.size,
            height: widget.size,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.baseline,
                  textBaseline: TextBaseline.alphabetic,
                  children: [
                    Text(
                      '$currentScore',
                      style: widget.size > 90
                          ? AppTypography.scoreNumber
                          : AppTypography.titleLarge,
                    ),
                    if (!widget.showPercent)
                      Text(
                        ' /${widget.maxScore}',
                        style: AppTypography.captionMedium.copyWith(
                          color: AppColors.textTertiary,
                          fontSize: widget.size > 90 ? 13 : 11,
                        ),
                      )
                    else
                      Text(
                        '%',
                        style: AppTypography.captionMedium.copyWith(
                          color: AppColors.textPrimary,
                          fontSize: widget.size > 90 ? 14 : 11,
                        ),
                      ),
                  ],
                ),
                if (widget.label != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    widget.label!,
                    style: AppTypography.caption.copyWith(
                      fontSize: widget.size > 90 ? 11 : 9,
                      color: AppColors.textSecondary,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ],
            ),
          ),
        );
      },
    );
  }
}

class _ScoreRingPainter extends CustomPainter {
  final double progress;
  final double strokeWidth;
  final Color activeColor;
  final Color trackColor;

  const _ScoreRingPainter({
    required this.progress,
    required this.strokeWidth,
    required this.activeColor,
    required this.trackColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final radius = (size.width - strokeWidth) / 2;

    // Background track
    final trackPaint = Paint()
      ..color = trackColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = strokeWidth
      ..strokeCap = StrokeCap.round;

    canvas.drawCircle(center, radius, trackPaint);

    // Active progress arc
    if (progress > 0) {
      final activePaint = Paint()
        ..color = activeColor
        ..style = PaintingStyle.stroke
        ..strokeWidth = strokeWidth
        ..strokeCap = StrokeCap.round;

      const startAngle = -math.pi / 2;
      final sweepAngle = 2 * math.pi * progress;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: radius),
        startAngle,
        sweepAngle,
        false,
        activePaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _ScoreRingPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.activeColor != activeColor;
  }
}

