import 'package:flutter/foundation.dart';
import '../core/errors/app_error.dart';
import '../models/authentication_result.dart';
import '../models/evidence.dart';
import '../models/evidence_validation.dart';
import '../models/product.dart';
import '../models/product_identification.dart';
import '../repositories/authentication_repository.dart';
import '../repositories/history_repository.dart';
import '../services/image_quality_checker.dart';
import '../services/storage_service.dart';

/// Drives the guided first scan.
///
/// It runs the same real pipeline as the main flow: no sample product, no
/// stand-in checklist and no fabricated report if a request fails (§30, §46).
/// Preference steps are entirely optional (§1).
class OnboardingViewModel extends ChangeNotifier {
  final StorageService? _storageService;
  final HistoryRepository? _historyRepo;
  AuthenticationRepository? _authRepo;

  static const int lastStep = 12;

  int _currentStep = 1;

  /// Preferences are unset until the user chooses. Nothing is preselected and
  /// nothing blocks progress.
  String _selectedGoal = '';
  String _selectedKnowledge = '';
  bool _authenticityChecks = true;
  bool _physicalTips = true;
  bool _detailedReports = true;
  bool _isCompleted = false;

  String? _capturedImagePath;
  final Map<String, String> _capturedPhotos = {};

  Product? _identifiedProduct;
  bool _isIdentifying = false;
  String? _identificationError;

  List<EvidenceItem> _dynamicChecklist = [];
  int _evidenceCaptureIndex = 0;
  bool _isLoadingChecklist = false;

  bool _isValidatingPhoto = false;
  EvidenceValidationResult? _pendingValidation;
  String? _pendingPhotoPath;
  String? _validationError;

  bool _isAnalyzing = false;
  String? _analysisError;
  AuthenticationReport? _onboardingReport;

  OnboardingViewModel({
    StorageService? storageService,
    AuthenticationRepository? authRepo,
    HistoryRepository? historyRepo,
  })  : _storageService = storageService,
        _authRepo = authRepo,
        _historyRepo = historyRepo {
    final s = _storageService;
    if (s != null) {
      _isCompleted = s.getBool('onboarding_completed', defaultValue: false);
      _selectedGoal = s.getString('onboarding_goal') ?? '';
      _selectedKnowledge = s.getString('onboarding_focus') ?? '';
      _authenticityChecks = s.getBool('onboarding_auth_checks', defaultValue: true);
      _physicalTips = s.getBool('onboarding_physical_tips', defaultValue: true);
      _detailedReports = s.getBool('onboarding_detailed_reports', defaultValue: true);
    }
  }

  void updateAuthRepo(AuthenticationRepository authRepo) {
    _authRepo = authRepo;
  }

  // ------------------------------------------------------------- getters
  int get currentStep => _currentStep;
  String get selectedGoal => _selectedGoal;
  String get selectedKnowledge => _selectedKnowledge;
  bool get authenticityChecks => _authenticityChecks;
  bool get physicalTips => _physicalTips;
  bool get detailedReports => _detailedReports;
  bool get isCompleted => _isCompleted;

  String? get capturedImagePath => _capturedImagePath;
  Map<String, String> get capturedPhotos => Map.unmodifiable(_capturedPhotos);

  Product? get identifiedProduct => _identifiedProduct;
  bool get isIdentifying => _isIdentifying;
  String? get identificationError => _identificationError;

  List<EvidenceItem> get dynamicChecklist => List.unmodifiable(_dynamicChecklist);
  int get evidenceCaptureIndex => _evidenceCaptureIndex;
  bool get isLoadingChecklist => _isLoadingChecklist;

  bool get isValidatingPhoto => _isValidatingPhoto;
  EvidenceValidationResult? get pendingValidation => _pendingValidation;
  String? get pendingPhotoPath => _pendingPhotoPath;
  String? get validationError => _validationError;

  bool get isAnalyzing => _isAnalyzing;
  String? get analysisError => _analysisError;
  AuthenticationReport? get onboardingReport => _onboardingReport;

  EvidenceItem? get currentChecklistItem {
    if (_dynamicChecklist.isEmpty) return null;
    final i = _evidenceCaptureIndex.clamp(0, _dynamicChecklist.length - 1);
    return _dynamicChecklist[i];
  }

  EvidenceItem? get targetEvidenceItem => currentChecklistItem;

  int get requiredChecklistCount => _dynamicChecklist.where((e) => e.isCritical).length;
  int get capturedRequiredChecklistCount =>
      _dynamicChecklist.where((e) => e.isCritical && _capturedPhotos.containsKey(e.id)).length;
  int get capturedTotalChecklistCount => _capturedPhotos.length;

  /// Nothing is mandatory. With no evidence angles supplied the first photo
  /// alone is analysed, which will read as inconclusive (§4, §27).
  bool get canFinishEvidence =>
      _capturedPhotos.isNotEmpty || (_capturedImagePath?.isNotEmpty ?? false);

  // ---------------------------------------------------------- navigation
  void nextStep() {
    if (_currentStep < lastStep) {
      _currentStep++;
      notifyListeners();
    } else {
      finishOnboarding();
    }
  }

  void previousStep() {
    if (_currentStep > 1) {
      _currentStep--;
      notifyListeners();
    }
  }

  void jumpToStep(int step) {
    if (step >= 1 && step <= lastStep) {
      _currentStep = step;
      notifyListeners();
    }
  }

  // --------------------------------------------------------- preferences
  // Selecting a preference is optional and changes emphasis only, never the
  // authenticity score (§1).
  void selectGoal(String goal) {
    _selectedGoal = _selectedGoal == goal ? '' : goal;
    _storageService?.setString('onboarding_goal', _selectedGoal);
    notifyListeners();
  }

  void selectKnowledge(String knowledge) {
    _selectedKnowledge = _selectedKnowledge == knowledge ? '' : knowledge;
    _storageService?.setString('onboarding_focus', _selectedKnowledge);
    notifyListeners();
  }

  void toggleAuthenticityChecks(bool val) {
    _authenticityChecks = val;
    _storageService?.setBool('onboarding_auth_checks', val);
    notifyListeners();
  }

  void togglePhysicalTips(bool val) {
    _physicalTips = val;
    _storageService?.setBool('onboarding_physical_tips', val);
    notifyListeners();
  }

  void toggleDetailedReports(bool val) {
    _detailedReports = val;
    _storageService?.setBool('onboarding_detailed_reports', val);
    notifyListeners();
  }

  void finishOnboarding() {
    _isCompleted = true;
    _storageService?.setBool('onboarding_completed', true);
    notifyListeners();
  }

  // ------------------------------------------------------------- capture
  void setCapturedImage(String? path) {
    _capturedImagePath = path;
    notifyListeners();
  }

  void setEvidenceCaptureIndex(int index) {
    if (index >= 0 && index < _dynamicChecklist.length) {
      _evidenceCaptureIndex = index;
      notifyListeners();
    }
  }

  String _describe(Object e) {
    if (e is AppError) return '${e.title}\n${e.message}';
    return e.toString().replaceAll('Exception: ', '');
  }

  /// Identifies the first photo, then loads the product-specific plan.
  Future<void> identifyCapturedItem(String imagePath) async {
    final repo = _authRepo;

    _isIdentifying = true;
    _identificationError = null;
    _identifiedProduct = null;
    _dynamicChecklist = [];
    _onboardingReport = null;
    _capturedPhotos.clear();
    _evidenceCaptureIndex = 0;
    notifyListeners();

    if (repo == null) {
      _identificationError = 'Analysis is unavailable right now. Please try again later.';
      _isIdentifying = false;
      notifyListeners();
      return;
    }

    try {
      final storedPath = await repo.persistCapturedImage(
        imagePath,
        prefix: 'onboarding',
        stripExif: _storageService?.getBool('anonymous_scanning', defaultValue: false) ?? false,
      );
      _capturedImagePath = storedPath;

      final quality = await ImageQualityChecker.evaluate(storedPath);
      if (!quality.isUsable) {
        _identificationError = quality.message;
        _isIdentifying = false;
        notifyListeners();
        return;
      }

      final ident = await repo.identifyProduct(storedPath);
      if (!ident.productDetected ||
          ident.status != IdentificationStatus.productDetected ||
          ident.identificationConfidence < 0.70) {
        _identificationError = ident.message;
        _isIdentifying = false;
        notifyListeners();
        return;
      }

      _identifiedProduct = ident.toProduct(imageAsset: storedPath);
      _isIdentifying = false;
      _isLoadingChecklist = true;
      notifyListeners();

      _dynamicChecklist = List<EvidenceItem>.from(
        await repo.getRequiredEvidence(_identifiedProduct!),
      );
      _evidenceCaptureIndex = 0;
    } catch (e) {
      if (kDebugMode) debugPrint('[Onboarding] identification failed: $e');
      _identificationError = _describe(e);
    } finally {
      _isIdentifying = false;
      _isLoadingChecklist = false;
      notifyListeners();
    }
  }

  Future<void> retryIdentification() async {
    final path = _capturedImagePath;
    if (path != null) await identifyCapturedItem(path);
  }

  /// Validates a submitted evidence photo before it can count (§6, §7).
  Future<void> submitEvidencePhoto(String imagePath) async {
    final repo = _authRepo;
    final item = currentChecklistItem;
    final product = _identifiedProduct;
    if (repo == null || item == null || product == null) return;

    _isValidatingPhoto = true;
    _validationError = null;
    _pendingValidation = null;
    notifyListeners();

    try {
      final storedPath = await repo.persistCapturedImage(
        imagePath,
        prefix: item.id,
        stripExif: _storageService?.getBool('anonymous_scanning', defaultValue: false) ?? false,
      );
      _pendingPhotoPath = storedPath;
      _pendingValidation = await repo.validateEvidencePhoto(
        imagePath: storedPath,
        requestedItem: item,
        product: product,
      );
    } catch (e) {
      _validationError = _describe(e);
    } finally {
      _isValidatingPhoto = false;
      notifyListeners();
    }
  }

  /// Accepts the reviewed photo. Wrong-subject photos can never be forced in.
  void acceptPendingPhoto({bool force = false}) {
    final item = currentChecklistItem;
    final validation = _pendingValidation;
    final path = _pendingPhotoPath;
    if (item == null || validation == null || path == null) return;
    if (!validation.isAccepted && !(force && validation.isOverridable)) return;

    _capturedPhotos[item.id] = path;
    final idx = _dynamicChecklist.indexWhere((e) => e.id == item.id);
    if (idx != -1) {
      _dynamicChecklist[idx] = _dynamicChecklist[idx].copyWith(
        capturedImagePath: path,
        status: EvidenceStatus.captured,
        validation: validation,
        keptDespiteLowQuality: !validation.isAccepted,
      );
    }

    _pendingValidation = null;
    _pendingPhotoPath = null;
    _advance();
  }

  void discardPendingPhoto() {
    _pendingValidation = null;
    _pendingPhotoPath = null;
    notifyListeners();
  }

  /// Kept for the guided screen: submit, then accept if the check passed.
  Future<void> recordEvidencePhoto(String imagePath) async {
    await submitEvidencePhoto(imagePath);
    if (_pendingValidation?.isAccepted ?? false) {
      acceptPendingPhoto();
    }
  }

  void markCurrentEvidenceUnavailable() {
    final item = currentChecklistItem;
    if (item == null) return;
    _capturedPhotos.remove(item.id);
    final idx = _dynamicChecklist.indexWhere((e) => e.id == item.id);
    if (idx != -1) {
      _dynamicChecklist[idx] = _dynamicChecklist[idx].copyWith(
        status: EvidenceStatus.unavailable,
        capturedImagePath: '',
      );
    }
    _advance();
  }

  Future<void> skipCurrentOptionalEvidence() async {
    _advance();
  }

  void _advance() {
    for (int i = _evidenceCaptureIndex + 1; i < _dynamicChecklist.length; i++) {
      final e = _dynamicChecklist[i];
      if (!_capturedPhotos.containsKey(e.id) && !e.isUnavailable) {
        _evidenceCaptureIndex = i;
        notifyListeners();
        return;
      }
    }
    notifyListeners();
  }

  // ------------------------------------------------------------ analysis
  Future<void> finishAndAnalyze() async {
    final repo = _authRepo;
    final product = _identifiedProduct;

    _currentStep = 8;
    _isAnalyzing = true;
    _analysisError = null;
    notifyListeners();

    if (repo == null || product == null) {
      _analysisError = 'Analysis is unavailable right now. Please try again later.';
      _isAnalyzing = false;
      notifyListeners();
      return;
    }

    try {
      final report = await repo.finalizeReport(
        product: product,
        evidenceItems: _dynamicChecklist,
        capturedImages: Map<String, String>.from(_capturedPhotos),
        overviewImagePath: _capturedImagePath,
        identificationConfidence:
            (product.identificationConfidence * 100).round().clamp(0, 99),
      );
      _onboardingReport = report;
      _dynamicChecklist = List<EvidenceItem>.from(report.evidenceItems);
      // The first scan is a real scan: it belongs in history.
      _historyRepo?.addReport(report);
      _analysisError = null;
    } catch (e) {
      if (kDebugMode) debugPrint('[Onboarding] analysis failed: $e');
      _analysisError = _describe(e);
      _onboardingReport = null;
    } finally {
      _isAnalyzing = false;
      notifyListeners();
    }
  }

  Future<void> retryAnalysis() => finishAndAnalyze();

  void reset() {
    _currentStep = 1;
    _isCompleted = false;
    _capturedImagePath = null;
    _capturedPhotos.clear();
    _evidenceCaptureIndex = 0;
    _identifiedProduct = null;
    _isIdentifying = false;
    _identificationError = null;
    _dynamicChecklist = [];
    _isLoadingChecklist = false;
    _pendingValidation = null;
    _pendingPhotoPath = null;
    _validationError = null;
    _isAnalyzing = false;
    _analysisError = null;
    _onboardingReport = null;
    _storageService?.setBool('onboarding_completed', false);
    notifyListeners();
  }
}
