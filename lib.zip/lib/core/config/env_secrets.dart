// DEVELOPMENT ONLY - DO NOT COMMIT THIS FILE TO VERSION CONTROL
// This file is strictly excluded by .gitignore.

class EnvSecrets {
  /// Priority:
  /// 1. Compile-time flag: --dart-define=GEMINI_API_KEY=your_key
  /// 2. Development secret constant for local prototype testing
  static const String geminiApiKey = String.fromEnvironment(
    'GEMINI_API_KEY',
    defaultValue: '',
  );
}
