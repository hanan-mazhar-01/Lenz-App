import '../models/authentication_result.dart';
import '../models/evidence.dart';
import '../models/photo_quality.dart';
import '../models/product.dart';
import '../models/product_identification.dart';

enum ScanLifecycleState {
  idle,
  initializingCamera,
  capturing,
  preview,
  identifying,
  identified,
  planningEvidence,
  capturingEvidence,
  evidenceComplete,
  analyzing,
  resultReady,
  saving,
  saved,
  error,
}

/// Single source of truth for an in-progress or completed scan session.
class ScanSession {
  final String id;
  final String? firstImage;
  final ProductIdentification? identification;
  final Product? product;
  final List<EvidenceItem> evidencePlan;
  final Map<String, String> capturedEvidence; // evidenceId -> local file path
  final Map<String, PhotoQualityResult> qualityResults; // evidenceId -> quality
  final dynamic analysis; // raw or structured observation results
  final AuthenticationReport? result;
  final DateTime createdAt;
  final String? errorMessage;

  const ScanSession({
    required this.id,
    this.firstImage,
    this.identification,
    this.product,
    this.evidencePlan = const [],
    this.capturedEvidence = const {},
    this.qualityResults = const {},
    this.analysis,
    this.result,
    required this.createdAt,
    this.errorMessage,
  });

  factory ScanSession.fresh() => ScanSession(
        id: 'scan_${DateTime.now().millisecondsSinceEpoch}',
        createdAt: DateTime.now(),
      );

  ScanSession copyWith({
    String? id,
    String? firstImage,
    ProductIdentification? identification,
    Product? product,
    List<EvidenceItem>? evidencePlan,
    Map<String, String>? capturedEvidence,
    Map<String, PhotoQualityResult>? qualityResults,
    dynamic analysis,
    AuthenticationReport? result,
    DateTime? createdAt,
    String? errorMessage,
  }) {
    return ScanSession(
      id: id ?? this.id,
      firstImage: firstImage ?? this.firstImage,
      identification: identification ?? this.identification,
      product: product ?? this.product,
      evidencePlan: evidencePlan ?? this.evidencePlan,
      capturedEvidence: capturedEvidence ?? this.capturedEvidence,
      qualityResults: qualityResults ?? this.qualityResults,
      analysis: analysis ?? this.analysis,
      result: result ?? this.result,
      createdAt: createdAt ?? this.createdAt,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }
}

