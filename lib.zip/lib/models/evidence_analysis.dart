import 'authentication_result.dart';
import 'evidence.dart';
import 'product.dart';

enum PartStatus {
  consistent('Consistent'),
  needsReview('Needs Review'),
  suspicious('Suspicious'),
  unknown('Unknown / Not Provided');

  final String label;
  const PartStatus(this.label);
}

class PartAnalysis {
  final String id;
  final int score;
  final PartStatus status;
  final String explanation;

  const PartAnalysis({
    required this.id,
    required this.score,
    required this.status,
    required this.explanation,
  });

  factory PartAnalysis.fromJson(Map<String, dynamic> json) {
    final statusStr = (json['status'] as String? ?? 'CONSISTENT').toUpperCase();
    PartStatus status;
    if (statusStr.contains('SUSPICIOUS') || statusStr.contains('REPLICA') || statusStr.contains('FAKE')) {
      status = PartStatus.suspicious;
    } else if (statusStr.contains('REVIEW') || statusStr.contains('NEEDS_REVIEW') || statusStr.contains('WARN')) {
      status = PartStatus.needsReview;
    } else if (statusStr.contains('UNKNOWN') || statusStr.contains('MISSING')) {
      status = PartStatus.unknown;
    } else {
      status = PartStatus.consistent;
    }

    final scoreRaw = json['score'] ?? 80;
    int score = 80;
    if (scoreRaw is num) {
      score = scoreRaw.toInt();
      if (score <= 1) score = (score * 100).toInt();
    }

    return PartAnalysis(
      id: json['id'] as String? ?? '',
      score: score.clamp(0, 100),
      status: status,
      explanation: json['explanation'] as String? ?? 'Analysis consistent with manufacturer specifications.',
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'score': score,
        'status': status.name.toUpperCase(),
        'explanation': explanation,
      };
}

class GeminiPhysicalCheck {
  final String title;
  final String description;
  final String whatToLookFor;

  const GeminiPhysicalCheck({
    required this.title,
    required this.description,
    required this.whatToLookFor,
  });

  factory GeminiPhysicalCheck.fromJson(Map<String, dynamic> json) {
    return GeminiPhysicalCheck(
      title: json['title'] as String? ?? 'Physical Inspection',
      description: json['description'] as String? ?? '',
      whatToLookFor: json['what_to_look_for'] as String? ?? '',
    );
  }

  Map<String, dynamic> toJson() => {
        'title': title,
        'description': description,
        'what_to_look_for': whatToLookFor,
      };
}

class EvidenceAnalysisResult {
  final Verdict verdict;
  final int overallScore;
  final double confidence;
  final String summary;
  final List<String> positiveFindings;
  final List<String> suspiciousFindings;
  final List<PartAnalysis> evidenceAnalyses;
  final List<String> missingEvidence;
  final String nextAction;
  final List<GeminiPhysicalCheck> physicalChecks;

  const EvidenceAnalysisResult({
    required this.verdict,
    required this.overallScore,
    required this.confidence,
    required this.summary,
    required this.positiveFindings,
    required this.suspiciousFindings,
    required this.evidenceAnalyses,
    required this.missingEvidence,
    required this.nextAction,
    required this.physicalChecks,
  });

  factory EvidenceAnalysisResult.fromJson(Map<String, dynamic> json) {
    final resultStr = (json['result'] as String? ?? 'INCONCLUSIVE').toUpperCase();
    Verdict verdict;
    if (resultStr.contains('AUTHENTIC')) {
      verdict = Verdict.likelyAuthentic;
    } else if (resultStr.contains('REPLICA') || resultStr.contains('FAKE')) {
      verdict = Verdict.likelyReplica;
    } else {
      verdict = Verdict.inconclusive;
    }

    final scoreRaw = json['overall_score'] ?? json['score'] ?? 75;
    int score = 75;
    if (scoreRaw is num) {
      score = scoreRaw.toInt();
      if (score <= 1) score = (score * 100).toInt();
    }

    final confRaw = json['confidence'] ?? 0.8;
    double conf = 0.8;
    if (confRaw is num) {
      conf = confRaw.toDouble();
      if (conf > 1.0) conf = conf / 100.0;
    }

    final positives = <String>[];
    if (json['positive_findings'] is List) {
      for (final p in json['positive_findings'] as List) {
        if (p != null) positives.add(p.toString());
      }
    }

    final suspicious = <String>[];
    if (json['suspicious_findings'] is List) {
      for (final s in json['suspicious_findings'] as List) {
        if (s != null) suspicious.add(s.toString());
      }
    }

    final missing = <String>[];
    if (json['missing_evidence'] is List) {
      for (final m in json['missing_evidence'] as List) {
        if (m != null) missing.add(m.toString());
      }
    }

    final analyses = <PartAnalysis>[];
    if (json['evidence'] is List) {
      for (final e in json['evidence'] as List) {
        if (e is Map<String, dynamic>) {
          analyses.add(PartAnalysis.fromJson(e));
        } else if (e is Map) {
          analyses.add(PartAnalysis.fromJson(Map<String, dynamic>.from(e)));
        }
      }
    }

    final checks = <GeminiPhysicalCheck>[];
    if (json['physical_checks'] is List) {
      for (final c in json['physical_checks'] as List) {
        if (c is Map<String, dynamic>) {
          checks.add(GeminiPhysicalCheck.fromJson(c));
        } else if (c is Map) {
          checks.add(GeminiPhysicalCheck.fromJson(Map<String, dynamic>.from(c)));
        }
      }
    }

    return EvidenceAnalysisResult(
      verdict: verdict,
      overallScore: score.clamp(0, 100),
      confidence: conf,
      summary: json['summary'] as String? ?? 'Analysis completed using multimodal visual verification.',
      positiveFindings: positives,
      suspiciousFindings: suspicious,
      evidenceAnalyses: analyses,
      missingEvidence: missing,
      nextAction: json['next_action'] as String? ?? '',
      physicalChecks: checks,
    );
  }

  AuthenticationReport toAuthenticationReport({
    required Product product,
    required List<EvidenceItem> capturedItems,
    String? id,
  }) {
    // Map captured evidence items with real Gemini scores and explanations
    final updatedEvidence = <EvidenceItem>[];
    for (int i = 0; i < capturedItems.length; i++) {
      final item = capturedItems[i];
      final partMatch = evidenceAnalyses.firstWhere(
        (a) => a.id.toLowerCase() == item.id.toLowerCase() ||
            item.title.toLowerCase().contains(a.id.toLowerCase()) ||
            a.id.toLowerCase().contains(item.title.toLowerCase()),
        orElse: () => PartAnalysis(
          id: item.id,
          score: overallScore,
          status: PartStatus.consistent,
          explanation: 'Inspected visually during multi-angle verification.',
        ),
      );

      final matchingCheck = physicalChecks.firstWhere(
        (c) => c.title.toLowerCase().contains(item.title.toLowerCase()) ||
            item.title.toLowerCase().contains(c.title.toLowerCase()),
        orElse: () => GeminiPhysicalCheck(
          title: item.title,
          description: partMatch.explanation,
          whatToLookFor: 'Compare sharpness, engraving depth, and kerning against genuine references.',
        ),
      );

      updatedEvidence.add(item.copyWith(
        score: partMatch.score,
        whyCorrect: partMatch.explanation,
        whatToLookFor: [
          matchingCheck.description,
          matchingCheck.whatToLookFor,
        ].where((s) => s.isNotEmpty).toList(),
      ));
    }

    final quickPoints = <String>[];
    if (positiveFindings.isNotEmpty) {
      quickPoints.addAll(positiveFindings.take(2));
    }
    if (suspiciousFindings.isNotEmpty) {
      quickPoints.addAll(suspiciousFindings.take(2));
    }
    if (quickPoints.isEmpty) {
      quickPoints.add(summary);
    }

    return AuthenticationReport(
      id: id ?? 'rep_${DateTime.now().millisecondsSinceEpoch}',
      product: product,
      verdict: verdict,
      overallScore: overallScore,
      quickSummaryPoints: quickPoints,
      evidenceItems: updatedEvidence,
      rationale: summary,
      timestamp: DateTime.now(),
      isFavorite: false,
    );
  }
}
