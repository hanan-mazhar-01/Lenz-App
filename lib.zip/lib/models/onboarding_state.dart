class OnboardingState {
  final String primaryGoal;
  final String preferredFocus;
  final String preferredExperience;
  final bool authenticityChecks;
  final bool physicalTips;
  final bool detailedReports;
  final bool isCompleted;

  const OnboardingState({
    this.primaryGoal = 'Before I buy',
    this.preferredFocus = 'Is it likely authentic?',
    this.preferredExperience = 'Guided verification',
    this.authenticityChecks = true,
    this.physicalTips = true,
    this.detailedReports = true,
    this.isCompleted = false,
  });

  OnboardingState copyWith({
    String? primaryGoal,
    String? preferredFocus,
    String? preferredExperience,
    bool? authenticityChecks,
    bool? physicalTips,
    bool? detailedReports,
    bool? isCompleted,
  }) {
    return OnboardingState(
      primaryGoal: primaryGoal ?? this.primaryGoal,
      preferredFocus: preferredFocus ?? this.preferredFocus,
      preferredExperience: preferredExperience ?? this.preferredExperience,
      authenticityChecks: authenticityChecks ?? this.authenticityChecks,
      physicalTips: physicalTips ?? this.physicalTips,
      detailedReports: detailedReports ?? this.detailedReports,
      isCompleted: isCompleted ?? this.isCompleted,
    );
  }

  Map<String, dynamic> toJson() => {
        'primaryGoal': primaryGoal,
        'preferredFocus': preferredFocus,
        'preferredExperience': preferredExperience,
        'authenticityChecks': authenticityChecks,
        'physicalTips': physicalTips,
        'detailedReports': detailedReports,
        'isCompleted': isCompleted,
      };

  factory OnboardingState.fromJson(Map<String, dynamic> json) => OnboardingState(
        primaryGoal: json['primaryGoal'] as String? ?? 'Before I buy',
        preferredFocus: json['preferredFocus'] as String? ?? 'Is it likely authentic?',
        preferredExperience: json['preferredExperience'] as String? ?? 'Guided verification',
        authenticityChecks: json['authenticityChecks'] as bool? ?? true,
        physicalTips: json['physicalTips'] as bool? ?? true,
        detailedReports: json['detailedReports'] as bool? ?? true,
        isCompleted: json['isCompleted'] as bool? ?? false,
      );
}

