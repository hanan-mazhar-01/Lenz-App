import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_typography.dart';
import '../../models/authentication_result.dart';
import '../../models/evidence.dart';
import '../../models/evidence_observation.dart';
import '../../models/product.dart';
import '../../data/authentication_rules.dart';
import '../../models/evidence_validation.dart';
import '../../models/photo_quality.dart';
import '../../services/authentication_scoring_engine.dart';
import '../../widgets/animations/bounce_button.dart';
import '../../widgets/cards/glass_card.dart';
import '../../widgets/cards/verdict_badge.dart';
import '../../widgets/common/app_image.dart';
import '../../services/haptics.dart';

enum QaTestStatus { pending, running, passed, failed }

class QaTestCase {
  final String id;
  final String title;
  final String description;
  final Product product;
  final List<EvidenceItem> requiredEvidence;
  final Map<String, String> capturedImages;
  final List<PartObservation> observations;
  final List<CrossImageContradiction> contradictions;
  final int averageQuality;
  final Verdict expectedVerdict;
  final bool expectAuthenticCeiling; // Must NOT receive > 70% Authentic

  QaTestStatus status;
  ScoringEngineResult? result;
  String? failureReason;

  QaTestCase({
    required this.id,
    required this.title,
    required this.description,
    required this.product,
    required this.requiredEvidence,
    required this.capturedImages,
    required this.observations,
    this.contradictions = const [],
    this.averageQuality = 85,
    required this.expectedVerdict,
    this.expectAuthenticCeiling = true,
    this.status = QaTestStatus.pending,
  });
}

class DeveloperQaScreen extends StatefulWidget {
  const DeveloperQaScreen({super.key});

  @override
  State<DeveloperQaScreen> createState() => _DeveloperQaScreenState();
}

class _DeveloperQaScreenState extends State<DeveloperQaScreen> {
  late List<QaTestCase> _tests;
  bool _isRunningAll = false;

  @override
  void initState() {
    super.initState();
    _initTestCases();
  }

  void _initTestCases() {
    const replicaWatch = Product(
      id: 'prod_replica_submariner',
      name: 'Rolex Submariner Date (Replica Sample)',
      brand: 'Rolex',
      model: '116610LN',
      category: ProductCategory.watches,
      imageAsset: 'assets/images/watch_full.png',
    );

    final standardEvidence = [
      const EvidenceItem(
        id: 'watch_full',
        index: 1,
        title: 'Full Watch Face & Case',
        guide: 'Straight-on shot of the watch.',
        imageAsset: 'assets/images/watch_full.png',
        isRequired: true,
      ),
      const EvidenceItem(
        id: 'watch_dial',
        index: 2,
        title: 'Dial & Typography',
        guide: 'Macro shot of dial and coronet.',
        imageAsset: 'assets/images/watch_dial.png',
        isRequired: true,
      ),
      const EvidenceItem(
        id: 'watch_crown',
        index: 3,
        title: 'Winding Crown & Guards',
        guide: 'Crown profile and guards.',
        imageAsset: 'assets/images/watch_crown.png',
        isRequired: true,
      ),
      const EvidenceItem(
        id: 'watch_caseback',
        index: 4,
        title: 'Caseback Finish',
        guide: 'Circular brushed finish on caseback.',
        imageAsset: 'assets/images/watch_caseback.png',
        isRequired: true,
      ),
      const EvidenceItem(
        id: 'watch_bracelet',
        index: 5,
        title: 'Bracelet & Clasp',
        guide: 'Oyster bracelet and clasp engravings.',
        imageAsset: 'assets/images/watch_bracelet.png',
        isRequired: true,
      ),
      const EvidenceItem(
        id: 'watch_reference',
        index: 6,
        title: 'Laser Rehaut & Serial',
        guide: 'Serial engraving at 6 o\'clock.',
        imageAsset: 'assets/images/watch_reference.png',
        isRequired: true,
      ),
    ];

    _tests = [
      // Test A: Full Replica Evidence
      QaTestCase(
        id: 'test_a',
        title: 'Test A: Known Replica Watch (Full Evidence)',
        description: 'Submits all 6 evidence photos of known replica watch. Engine must detect inconsistencies and NOT award high authentic confidence.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {for (final e in standardEvidence) e.id: e.imageAsset},
        observations: const [
          PartObservation(
            evidenceId: 'watch_full',
            title: 'Full Watch Face',
            observations: ['Bezel numerals lack depth; silver paint instead of platinum PVD'],
            consistentSignals: ['Ceramic insert color matches'],
            inconsistentSignals: ['Bezel numerals lack platinum depth'],
          ),
          PartObservation(
            evidenceId: 'watch_dial',
            title: 'Dial & Typography',
            observations: ['Cyclops 1.5x magnification', 'Coronet base oval round'],
            consistentSignals: ['Oyster Perpetual text is present'],
            inconsistentSignals: [
              'Cyclops date window lacks genuine 2.5x magnification',
              'Coronet base oval is round instead of flattened ellipse',
            ],
          ),
          PartObservation(
            evidenceId: 'watch_crown',
            title: 'Winding Crown',
            observations: ['Crown guards taper too sharply'],
            consistentSignals: ['Triplock dots present'],
            inconsistentSignals: ['Crown guard profile has incorrect sharp bevel'],
          ),
          PartObservation(
            evidenceId: 'watch_caseback',
            title: 'Caseback Finish',
            observations: ['Coarse brushed pattern with radial banding'],
            consistentSignals: [],
            inconsistentSignals: ['Caseback brushed grain is too coarse'],
          ),
          PartObservation(
            evidenceId: 'watch_bracelet',
            title: 'Bracelet & Clasp',
            observations: ['Solid end link has lateral play'],
            consistentSignals: ['Oyster link geometry is close'],
            inconsistentSignals: ['SEL fitment reveals gap between lug and bracelet end link'],
          ),
          PartObservation(
            evidenceId: 'watch_reference',
            title: 'Laser Rehaut',
            observations: ['Rehaut lettering ROLEX offset from minute indices'],
            consistentSignals: [],
            inconsistentSignals: ['Laser rehaut lettering does not align with dial minute markers'],
          ),
        ],
        expectedVerdict: Verdict.likelyReplica,
        expectAuthenticCeiling: true,
      ),

      // Test B: Partial Evidence (2/6 views)
      QaTestCase(
        id: 'test_b',
        title: 'Test B: Partial Evidence (Coverage Penalty)',
        description: 'Only 2 of 6 photos submitted. Engine must trigger coverage ceiling (<70%) and classify as Inconclusive.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {
          'watch_full': standardEvidence[0].imageAsset,
          'watch_dial': standardEvidence[1].imageAsset,
        },
        observations: const [
          PartObservation(
            evidenceId: 'watch_full',
            title: 'Full Watch',
            observations: ['Normal look'],
            consistentSignals: ['Black ceramic bezel insert matches reference color'],
          ),
          PartObservation(
            evidenceId: 'watch_dial',
            title: 'Dial',
            observations: ['Clean dial'],
            consistentSignals: ['Hour markers have white luminous infill'],
          ),
        ],
        expectedVerdict: Verdict.inconclusive,
      ),

      // Test C: Missing Caseback & Serial Checks
      QaTestCase(
        id: 'test_c',
        title: 'Test C: Missing Critical Serial / Caseback',
        description: '4 of 6 photos submitted, omitting critical serial and caseback. Must enforce Inconclusive verdict.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {
          'watch_full': standardEvidence[0].imageAsset,
          'watch_dial': standardEvidence[1].imageAsset,
          'watch_crown': standardEvidence[2].imageAsset,
          'watch_bracelet': standardEvidence[4].imageAsset,
        },
        observations: const [
          PartObservation(evidenceId: 'watch_full', title: 'Full Watch', consistentSignals: ['Dial layout consistent']),
          PartObservation(evidenceId: 'watch_dial', title: 'Dial', consistentSignals: ['Coronet print consistent']),
          PartObservation(evidenceId: 'watch_crown', title: 'Crown', consistentSignals: ['Triplock dots present']),
          PartObservation(evidenceId: 'watch_bracelet', title: 'Bracelet', consistentSignals: ['Clasp looks consistent']),
        ],
        expectedVerdict: Verdict.inconclusive,
      ),

      // Test D: Low Quality / Blur
      QaTestCase(
        id: 'test_d',
        title: 'Test D: Low Photo Quality / Blur Penalty',
        description: 'All 6 photos submitted but with severe blur (<55% quality score). Must trigger photo quality ceiling to Inconclusive.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {for (final e in standardEvidence) e.id: e.imageAsset},
        observations: [
          for (final item in standardEvidence)
            PartObservation(
              evidenceId: item.id,
              title: item.title,
              observations: const ['Photo is blurry and macro detail obscured'],
              consistentSignals: const ['Appears to resemble watch part'],
            ),
        ],
        averageQuality: 38,
        expectedVerdict: Verdict.inconclusive,
      ),

      // Test E: Cross-Image Contradiction
      QaTestCase(
        id: 'test_e',
        title: 'Test E: Cross-Image Contradiction',
        description: 'Critical conflict detected between bracelet lug serial and rehaut serial. Engine applies heavy penalty.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {for (final e in standardEvidence) e.id: e.imageAsset},
        observations: const [
          PartObservation(evidenceId: 'watch_full', title: 'Full Watch', consistentSignals: ['Bezel ceramic luster consistent']),
          PartObservation(evidenceId: 'watch_dial', title: 'Dial', consistentSignals: ['Font serifs look clean']),
        ],
        contradictions: const [
          CrossImageContradiction(
            description: 'Serial number visible between lugs does not match engraved serial on laser rehaut ring.',
            involvedPartIds: ['watch_bracelet', 'watch_reference'],
            severity: ContradictionSeverity.critical,
          ),
        ],
        expectedVerdict: Verdict.likelyReplica,
      ),

      // Test F: Known Authentic Reference
      QaTestCase(
        id: 'test_f',
        title: 'Test F: Known Authentic Reference Watch',
        description: 'All 6 views submitted with genuine manufacturer traits verified. Engine outputs Likely Authentic with calibrated score >= 80%.',
        product: replicaWatch,
        requiredEvidence: standardEvidence,
        capturedImages: {for (final e in standardEvidence) e.id: e.imageAsset},
        observations: const [
          PartObservation(
            evidenceId: 'watch_full',
            title: 'Full Watch',
            consistentSignals: ['Ceramic insert color and knurling factory compliant'],
          ),
          PartObservation(
            evidenceId: 'watch_dial',
            title: 'Dial',
            consistentSignals: ['Cyclops 2.5x magnification verified', 'Dial kerning authentic'],
          ),
          PartObservation(
            evidenceId: 'watch_crown',
            title: 'Crown',
            consistentSignals: ['Crown tooth pitch and chamfer match genuine specs'],
          ),
          PartObservation(
            evidenceId: 'watch_caseback',
            title: 'Caseback',
            consistentSignals: ['Caseback brushed grain matches Oystersteel standard'],
          ),
          PartObservation(
            evidenceId: 'watch_bracelet',
            title: 'Bracelet',
            consistentSignals: ['Solid end links fit completely flush with zero lug gap'],
          ),
          PartObservation(
            evidenceId: 'watch_reference',
            title: 'Laser Rehaut',
            consistentSignals: ['Laser rehaut aligns perfectly at every hour and minute marker'],
          ),
        ],
        averageQuality: 92,
        expectedVerdict: Verdict.likelyAuthentic,
      ),
    ];
  }

  /// Fixture helper: the in-app harness has no real images, so it states the
  /// quality level a scenario is meant to represent.
  static EvidenceValidationResult _syntheticValidation(EvidenceItem item, int quality) {
    return EvidenceValidationResult(
      requestedEvidenceId: item.id,
      requestedEvidenceTitle: item.title,
      evidenceTypeDetected: item.title,
      matchToRequestedEvidence: true,
      matchConfidence: 90,
      quality: PhotoQualityResult(
        qualityScore: quality,
        qualityStatus: PhotoQualityStatus.fromScore(quality),
        explanation: 'Fixture quality level',
        sharpness: quality,
        lighting: quality,
        framing: quality,
        detail: quality,
      ),
      usabilityScore: quality,
      authenticationUsefulness: quality,
      reason: 'Fixture',
    );
  }

  void _runSingleTest(int index) {
    final test = _tests[index];
    setState(() => test.status = QaTestStatus.running);

    Haptics.lightImpact();

    final rules = AuthenticationRules.resolve(
      category: test.product.category,
      brand: test.product.brand,
      model: test.product.model,
    );

    // Apply the rule set's weights and attach the fixture's stated photo
    // quality, so the engine sees the same shape it gets from a real scan.
    final evidence = test.requiredEvidence.map((item) {
      final hasPhoto = (test.capturedImages[item.id] ?? '').isNotEmpty;
      return item.copyWith(
        weight: rules.weightFor(item.id),
        capturedImagePath: test.capturedImages[item.id] ?? '',
        validation: hasPhoto
            ? _syntheticValidation(item, test.averageQuality)
            : null,
      );
    }).toList();

    final result = AuthenticationScoringEngine.evaluate(
      product: test.product,
      rawIdentificationConfidence: 94,
      requiredEvidence: evidence,
      capturedImages: test.capturedImages,
      observations: test.observations,
      contradictions: test.contradictions,
      rules: rules,
    );

    bool passed = false;
    String? failure;

    if (result.verdict != test.expectedVerdict) {
      failure = 'Expected ${test.expectedVerdict.label}, but got ${result.verdict.label} (${result.authenticationConfidence}%).';
    } else if (test.expectAuthenticCeiling &&
        test.expectedVerdict == Verdict.likelyReplica &&
        result.verdict == Verdict.likelyAuthentic) {
      failure = 'Replica received Likely Authentic rating! Ceiling failed.';
    } else {
      passed = true;
    }

    setState(() {
      test.result = result;
      test.status = passed ? QaTestStatus.passed : QaTestStatus.failed;
      test.failureReason = failure;
    });
  }

  Future<void> _runAllTests() async {
    setState(() => _isRunningAll = true);
    Haptics.mediumImpact();

    for (int i = 0; i < _tests.length; i++) {
      _runSingleTest(i);
      await Future.delayed(const Duration(milliseconds: 120));
    }

    if (mounted) {
      setState(() => _isRunningAll = false);
      final allPassed = _tests.every((t) => t.status == QaTestStatus.passed);
      if (allPassed) {
        Haptics.heavyImpact();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final totalPassed = _tests.where((t) => t.status == QaTestStatus.passed).length;
    final totalRun = _tests.where((t) => t.status != QaTestStatus.pending && t.status != QaTestStatus.running).length;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Developer QA Suite'),
        leading: IconButton(
          icon: const Icon(CupertinoIcons.chevron_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          children: [
            // Header Card
            GlassCard(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.accentSoft,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Icon(CupertinoIcons.checkmark_shield_fill, color: AppColors.accent, size: 22),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Authentication Engine Regressions', style: AppTypography.titleMedium),
                            const SizedBox(height: 2),
                            Text(
                              'Validates that known replica fixtures never receive false authentic ratings.',
                              style: AppTypography.caption,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Tests Passed: $totalPassed / ${_tests.length}',
                        style: AppTypography.captionMedium.copyWith(
                          color: totalRun > 0 && totalPassed == _tests.length ? AppColors.accent : AppColors.textPrimary,
                        ),
                      ),
                      if (_isRunningAll)
                        const CupertinoActivityIndicator()
                      else
                        BounceButton(
                          onTap: _runAllTests,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                            decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: BorderRadius.circular(18),
                            ),
                            child: Row(
                              children: [
                                const Icon(CupertinoIcons.play_fill, size: 12, color: AppColors.textInverse),
                                const SizedBox(width: 6),
                                Text(
                                  'Run All Tests',
                                  style: AppTypography.badge.copyWith(color: AppColors.textInverse),
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),
            Text('Regression Scenarios', style: AppTypography.titleMedium),
            const SizedBox(height: 12),

            // Test List
            ...List.generate(_tests.length, (index) {
              final test = _tests[index];
              return _buildTestCard(test, index);
            }),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _buildTestCard(QaTestCase test, int index) {
    Color statusBg = AppColors.neutralPill;
    Color statusFg = AppColors.textSecondary;
    IconData statusIcon = CupertinoIcons.clock;
    String statusText = 'Pending';

    switch (test.status) {
      case QaTestStatus.pending:
        statusBg = AppColors.neutralPill;
        statusFg = AppColors.textSecondary;
        statusIcon = CupertinoIcons.clock;
        statusText = 'Pending';
        break;
      case QaTestStatus.running:
        statusBg = AppColors.accentSoft;
        statusFg = AppColors.accent;
        statusIcon = CupertinoIcons.arrow_2_circlepath;
        statusText = 'Running';
        break;
      case QaTestStatus.passed:
        statusBg = AppColors.successBg;
        statusFg = AppColors.success;
        statusIcon = CupertinoIcons.checkmark_alt_circle_fill;
        statusText = 'Passed';
        break;
      case QaTestStatus.failed:
        statusBg = AppColors.dangerBg;
        statusFg = AppColors.danger;
        statusIcon = CupertinoIcons.xmark_circle_fill;
        statusText = 'Failed';
        break;
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: GlassCard(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(test.title, style: AppTypography.titleMedium.copyWith(fontSize: 15)),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: statusBg,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(statusIcon, size: 12, color: statusFg),
                      const SizedBox(width: 4),
                      Text(statusText, style: AppTypography.badge.copyWith(color: statusFg)),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(test.description, style: AppTypography.caption),
            const SizedBox(height: 10),

            // Fixture image thumbnails
            SizedBox(
              height: 48,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: test.capturedImages.length,
                separatorBuilder: (_, __) => const SizedBox(width: 8),
                itemBuilder: (ctx, i) {
                  final key = test.capturedImages.keys.elementAt(i);
                  final path = test.capturedImages[key]!;
                  return Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: AppColors.backgroundSecondary,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.borderLight),
                    ),
                    clipBehavior: Clip.antiAlias,
                    child: AppImage(imagePath: path, fit: BoxFit.cover),
                  );
                },
              ),
            ),

            if (test.result != null) ...[
              const SizedBox(height: 12),
              const Divider(),
              const SizedBox(height: 8),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Expected: ${test.expectedVerdict.label}', style: AppTypography.captionMedium),
                  Row(
                    children: [
                      Text('Actual: ', style: AppTypography.caption),
                      VerdictBadge(verdict: test.result!.verdict, isSmall: true),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text('Coverage: ${test.result!.evidenceCoverageText}', style: AppTypography.caption),
                  Text(
                    'Calibrated Score: ${test.result!.authenticationConfidence}%',
                    style: AppTypography.captionMedium.copyWith(
                      color: test.result!.verdict == Verdict.likelyAuthentic
                          ? AppColors.accent
                          : test.result!.verdict == Verdict.likelyReplica
                              ? AppColors.danger
                              : AppColors.warning,
                    ),
                  ),
                ],
              ),
              if (test.failureReason != null) ...[
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: AppColors.dangerBg,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    test.failureReason!,
                    style: AppTypography.caption.copyWith(color: AppColors.danger),
                  ),
                ),
              ],
            ],

            const SizedBox(height: 12),
            Align(
              alignment: Alignment.centerRight,
              child: BounceButton(
                onTap: () => _runSingleTest(index),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Text(
                    test.status == QaTestStatus.pending ? 'Run Test' : 'Re-run Test',
                    style: AppTypography.captionMedium.copyWith(fontSize: 12),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

